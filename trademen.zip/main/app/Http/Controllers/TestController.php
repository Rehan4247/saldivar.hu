<?php

namespace App\Http\Controllers;

class TestController extends Controller
{
    public function test()
    {

    }

    public function testPost()
    {

    }
}
