<?php
return [
    'prefix' => 'fake_',
    'model_path' => 'app/Models',
];