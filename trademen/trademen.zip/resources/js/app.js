require('./bootstrap');

window.Vue = require('vue');
