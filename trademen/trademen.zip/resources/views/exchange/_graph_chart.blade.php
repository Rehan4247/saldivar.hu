<div class="card lf-toggle-border-card lf-toggle-bg-card lf-toggle-text-color overflow-hidden h-100">
    <div class="card-body p-0">
        <div class="graph-loader">
            <div id="tv_chart_container" class="h-100"></div>
        </div>
    </div>
</div>
