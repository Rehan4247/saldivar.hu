<div class="nav lf-nav-tab lf-toggle-border-color border border-bottom-0" id="pills-tab" role="tablist">
    <a data-toggle="pill" class="nav-link active"
       href="#pills-withdrawal" id="pills-withdrawal-tab" aria-selected="true">{{ __('Withdrawal') }}</a>
    <a data-toggle="pill" class="nav-link"
       href="#pills-deposit" id="pills-deposit-tab" aria-selected="false">{{ __('Deposit') }}</a>
    <a data-toggle="pill" class="nav-link"
       href="#pills-trade" id="pills-trade-tab" aria-selected="false">{{ __('Trade') }}</a>
</div>
