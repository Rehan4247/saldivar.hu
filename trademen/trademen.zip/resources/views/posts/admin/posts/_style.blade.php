<link rel="stylesheet" href="{{ asset('plugins/jasny-bootstrap/css/jasny-bootstrap.min.css') }}">
<style>
    .thumbnail {
        width: 152px;
        max-height: 152px;
    }
    .thumbnail img {
        max-width: 100%;
    }
    .thumbnail i {
        font-size: 50px;
    }
</style>
